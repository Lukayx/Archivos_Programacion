#include <string>
#include <vector>

struct User{
  std::string userName;
  std::string password;
  std::vector<int> vector;
  bool admin;
};