En Bash: (En cmd hay errores de librerias)
  g++ main.cpp -o main
  ./main -u "Username" -p "Password" -v "{vector}"

g++ en su ultima actualizacion