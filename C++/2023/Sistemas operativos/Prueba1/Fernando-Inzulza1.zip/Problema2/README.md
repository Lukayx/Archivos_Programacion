En bash:
  g++ main.cpp -o main
  ./main

g++ en su ultima actualizacion