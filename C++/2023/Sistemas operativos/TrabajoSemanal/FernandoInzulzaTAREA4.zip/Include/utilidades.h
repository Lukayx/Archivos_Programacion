#include <cctype>

bool isSpecialCharacter(unsigned char c);